﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using Microsoft.VisualBasic.FileIO;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            string filePath = @"C:\C# practice\stock-prices.csv";
            string priceColumnName = "Close Price";

            List<string> uniqueSymbolNameList = excelReader.GetSymbolList(filePath);
            List<double> averagePriceList = new List<double>();
            List<double> maxPriceList = new List<double>();
            List<DateTime> dateList = new List<DateTime>();
            DateTime date = new DateTime();

            foreach (var symbol in uniqueSymbolNameList)
            {
                List<double> closePriceColumn = excelReader.getPriceColumn(filePath, priceColumnName, symbol);
                averagePriceList.Add(excelReader.GetAverage(closePriceColumn));
                maxPriceList.Add(excelReader.GetDateForMaxPrice(filePath, symbol, priceColumnName, out date));
                dateList.Add(date);
            }
        }
    }

    /// <summary>
    /// Class for performing operations on Excel.
    /// </summary>
    public class excelReader
    {
        /// <summary>
        /// For a given ticker-name and Price column name gets the values in form of double list.
        /// </summary>
        /// <param name="filePath"></param>
        /// <param name="columnName"></param>
        /// <param name="tickerName"></param>
        /// <returns></returns>
        public static List<double> getPriceColumn(string filePath, string columnName, string tickerName)
        {
            List<double> list = new List<double>();
            using (var reader = new StreamReader(filePath))
            {
                var headers = reader.ReadLine().Split(',');
                int columnIndex = Array.IndexOf(headers, columnName);
                int symbolIndex = Array.IndexOf(headers, "Symbol");
                string line = "";
                string[] values; 
                TextFieldParser parser = new TextFieldParser(new StringReader(line));

                while (!reader.EndOfStream)
                {
                    line = reader.ReadLine();
                    parser = new TextFieldParser(new StringReader(line));
                    parser.HasFieldsEnclosedInQuotes = true;
                    parser.SetDelimiters(",");
                    values = parser.ReadFields();
                    if (string.Equals(values[symbolIndex], tickerName))
                        list.Add(Convert.ToDouble(values[columnIndex]));
                }
            }
            return list;
        }

        /// <summary>
        /// Get the list of unique symbol values.
        /// </summary>
        /// <param name="filePath"></param>
        /// <returns></returns>
        public static List<string> GetSymbolList(string filePath)
        {
            List<string> list = new List<string>();
            using (var reader = new StreamReader(filePath))
            {
                var headers = reader.ReadLine().Split(',');
                int symbolIndex = Array.IndexOf(headers, "Symbol");
                string line = "";
                TextFieldParser parser = new TextFieldParser(new StringReader(line));
                string values;

                while (!reader.EndOfStream)
                {
                    line = reader.ReadLine();
                    parser = new TextFieldParser(new StringReader(line));
                    parser.HasFieldsEnclosedInQuotes = true;
                    parser.SetDelimiters(",");
                    values = parser.ReadFields()[symbolIndex];
                    if (!list.Contains(values))
                    {
                        list.Add(values);
                    }
                }
            }

            return list;
        }

        /// <summary>
        /// For a given price list returns a average value.
        /// </summary>
        /// <param name="priceList"></param>
        /// <returns></returns>
        public static double GetAverage(List<double> priceList)
        {
            return priceList.Average();
        }

        /// <summary>
        /// for a given ticker name and price column gets the max value of price and the corresponding date value.
        /// </summary>
        /// <param name="filePath"></param>
        /// <param name="tickerName"></param>
        /// <param name="priceName"></param>
        /// <param name="date"></param>
        /// <returns></returns>
        public static double GetDateForMaxPrice(string filePath, string tickerName, string priceName, out DateTime date)
        {
            List<DateTime> datelist = new List<DateTime>();
            List<double> priceList = new List<double>();

            using (var reader = new StreamReader(filePath))
            {
                var headers = reader.ReadLine().Split(',');
                int dateIndex = Array.IndexOf(headers, "Date");
                int symbolIndex = Array.IndexOf(headers, "Symbol");
                int priceIndex = Array.IndexOf(headers, priceName);
                string line = "";
                string[] values;
                TextFieldParser parser = new TextFieldParser(new StringReader(line));

                while (!reader.EndOfStream)
                {
                    line = reader.ReadLine();
                    parser = new TextFieldParser(new StringReader(line));
                    parser.HasFieldsEnclosedInQuotes = true;
                    parser.SetDelimiters(",");
                    values = parser.ReadFields();
                    if (string.Equals(values[symbolIndex], tickerName))
                    {
                        datelist.Add(Convert.ToDateTime(values[dateIndex]));
                        priceList.Add(Convert.ToDouble(values[priceIndex]));
                    }
                }
            }

            date = datelist[priceList.FindIndex(price => price == priceList.Max())];
            return priceList.Max();
        }
    }
}
